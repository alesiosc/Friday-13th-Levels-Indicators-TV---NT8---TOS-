#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private Friday13th.NT8_Friday13th_Levels[] cacheNT8_Friday13th_Levels;

		
		public Friday13th.NT8_Friday13th_Levels NT8_Friday13th_Levels(string set3Data)
		{
			return NT8_Friday13th_Levels(Input, set3Data);
		}


		
		public Friday13th.NT8_Friday13th_Levels NT8_Friday13th_Levels(ISeries<double> input, string set3Data)
		{
			if (cacheNT8_Friday13th_Levels != null)
				for (int idx = 0; idx < cacheNT8_Friday13th_Levels.Length; idx++)
					if (cacheNT8_Friday13th_Levels[idx].Set3Data == set3Data && cacheNT8_Friday13th_Levels[idx].EqualsInput(input))
						return cacheNT8_Friday13th_Levels[idx];
			return CacheIndicator<Friday13th.NT8_Friday13th_Levels>(new Friday13th.NT8_Friday13th_Levels(){ Set3Data = set3Data }, input, ref cacheNT8_Friday13th_Levels);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.Friday13th.NT8_Friday13th_Levels NT8_Friday13th_Levels(string set3Data)
		{
			return indicator.NT8_Friday13th_Levels(Input, set3Data);
		}


		
		public Indicators.Friday13th.NT8_Friday13th_Levels NT8_Friday13th_Levels(ISeries<double> input , string set3Data)
		{
			return indicator.NT8_Friday13th_Levels(input, set3Data);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.Friday13th.NT8_Friday13th_Levels NT8_Friday13th_Levels(string set3Data)
		{
			return indicator.NT8_Friday13th_Levels(Input, set3Data);
		}


		
		public Indicators.Friday13th.NT8_Friday13th_Levels NT8_Friday13th_Levels(ISeries<double> input , string set3Data)
		{
			return indicator.NT8_Friday13th_Levels(input, set3Data);
		}

	}
}

#endregion
